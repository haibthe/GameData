System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/bullet-617b536a.wasm")}}}));
